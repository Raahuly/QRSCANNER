﻿using Microsoft.AspNetCore.Http;


namespace MODEL
{
    public class QRScannerModel
    {
        public Int32? RowNum { get; set; }
        public int? ID { get; set; }
        public string? NAME { get; set; }
        public string? NUMBER { get; set; }
        public string? IMAGEPATH { get; set; }
        public string? QRCODE { get; set; }
        public IFormFile? File { get; set; }
        public int? ACTIVE { get; set; }
        public string? UNIQUEID { get; set; }
    }
}
