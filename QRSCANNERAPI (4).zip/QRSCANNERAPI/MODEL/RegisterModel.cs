﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class RegisterModel : ResponseStatusModel
    {
        public Int32? RowNum { get; set; }
        public int? ID { get; set; }
        public string? USERNAME { get; set; }
        public string? PASSWORD { get; set; }
        public string? EMAILID { get; set; }
        public string? MOBILENO { get; set; }
        public string? ADDRESS { get; set; }
        public string? ROLENAME { get; set; }
        public int? ROLEID { get; set; }
        public int? ACTIVE { get; set; }
    }
}
