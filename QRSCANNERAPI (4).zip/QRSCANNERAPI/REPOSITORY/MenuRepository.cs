﻿using Dapper;
using MODEL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REPOSITORY
{
    public class MenuRepository
    {
        private readonly Connection _connection;

        public MenuRepository(Connection connection)
        {
            _connection = connection;
        }

        public List<MenuModel> MenuAll()
        {
            List<MenuModel> menu = new List<MenuModel>();
            string sql = "[dbo].[ALLMENU]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, commandType: CommandType.StoredProcedure);
                menu = multi.Read<MenuModel>().ToList();
            }
            return menu;
        }

        public ResponseStatusModel AddMenu(MenuModel MM)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[ADDMENU]";
            using (IDbConnection conn = _connection.GetConnection())
            {

                var multi = conn.QueryMultiple(sql, new
                {
                    MM.PARENTID,
                    MM.MENUNAME,
                    MM.ACCESSIBLE,
                    MM.CONTROLLERNAME,
                    MM.ACTIONNAME,
                    MM.PARENTNAME
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

        public MenuModel ViewMenu(int MenuId)
        {
            MenuModel menu = new MenuModel();
            string sql = "[dbo].[GETBYMENUBYID]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    MENUID = MenuId
                }, commandType: CommandType.StoredProcedure);
                menu = multi.Read<MenuModel>().SingleOrDefault(); 
            }
            return menu;
        }
        
        public ResponseStatusModel UpdateMenu(MenuModel MM)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[UPDATEMENU]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    MM.PARENTID,
                    MM.MENUNAME,
                    MM.ACCESSIBLE,
                    MM.CONTROLLERNAME,
                    MM.ACTIONNAME,
                    MM.MENUID,
                    MM.PARENTNAME
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }


        public ResponseStatusModel DeleteMenu(int MENUID)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[REMOVEMENU]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    MENUID
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

    }
}
