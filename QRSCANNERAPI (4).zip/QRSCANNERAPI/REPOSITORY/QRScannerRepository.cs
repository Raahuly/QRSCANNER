﻿using Dapper;
using MODEL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REPOSITORY
{
    public class QRScannerRepository
    {
        private readonly Connection _connection;
        public QRScannerRepository(Connection connection)
        {
           _connection = connection;
        }

        public List<QRScannerModel> QRScanAll()
        {
            List<QRScannerModel> QRSCAN = new List<QRScannerModel>();
            string sql = "[dbo].[AllQRSCANNER]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, commandType: CommandType.StoredProcedure);
                QRSCAN = multi.Read<QRScannerModel>().ToList();
            }
            return QRSCAN;
        }

        public ResponseStatusModel AddQRScanner(QRScannerModel QC)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[AddQRSCANNERTABLE]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    QC.NAME,
                    QC.NUMBER,
                    QC.IMAGEPATH,
                    QC.UNIQUEID,
                    QC.QRCODE
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

        public string GetIdForQrCode(string Number)
        {
            string ID;
            string sql = "[dbo].[GETIDFORQRCODE]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    Number
                }, commandType: CommandType.StoredProcedure);
                ID = multi.Read<string>().SingleOrDefault();
            }
            return ID;
        }

    }
}
