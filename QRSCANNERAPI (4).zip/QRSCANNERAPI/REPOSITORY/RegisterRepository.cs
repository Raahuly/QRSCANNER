﻿using Dapper;
using MODEL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REPOSITORY
{
    public class RegisterRepository
    {
        private readonly Connection _connection;

        public RegisterRepository(Connection connection)
        {
            _connection = connection;
        }

        public List<RegisterModel> RegiterAll()
        {
            List<RegisterModel> register = new List<RegisterModel>();
            string sql = "[dbo].[ALLREGISTER]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, commandType: CommandType.StoredProcedure);
                register = multi.Read<RegisterModel>().ToList();
            }
            return register;
        }

        public ResponseStatusModel AddRegister(RegisterModel rm)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[ADDREGISTER]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    rm.USERNAME,
                    rm.PASSWORD,
                    rm.EMAILID,
                    rm.MOBILENO,
                    rm.ADDRESS,
                    rm.ROLENAME,
                    rm.ROLEID
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

        public RegisterModel ViewRegister(int ID)
        {
            RegisterModel reg = new RegisterModel();
            string sql = "[dbo].[GETBYREGISTERBYID]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    ID = ID
                }, commandType: CommandType.StoredProcedure);
                reg = multi.Read<RegisterModel>().SingleOrDefault();
            }
            return reg;
        }

        public ResponseStatusModel UpdateRegister(RegisterModel reg)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[UPDATEREGISTER]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    reg.USERNAME,
                    reg.PASSWORD,
                    reg.EMAILID,
                    reg.MOBILENO,
                    reg.ADDRESS,
                    reg.ROLENAME,
                    reg.ROLEID,
                    reg.ID
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

        public ResponseStatusModel DeleteRegister(int ID)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[REMOVEREGISTER]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    ID
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

    }
}
