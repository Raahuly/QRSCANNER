﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MODEL;
using REPOSITORY;

namespace QRSCANNERAPI.Controllers
{
    [Route("api/controller/Register")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        private readonly RegisterRepository _service;
        public RegisterController(RegisterRepository service)
        {
            _service = service;
        }

        [HttpGet]
        [Route("GetAllRegister")]
        public IActionResult GetAllRegister()
        {
            try
            {
                List<RegisterModel> register = _service.RegiterAll();
                return Ok(register);
            }
            catch(Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("AddRegister")]
        public IActionResult AddRegister(RegisterModel RM)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.AddRegister(RM);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("ViewRegister")]
        public IActionResult ViewRegister(int ID)
        {
            RegisterModel res = new RegisterModel();
            try
            {
                res = _service.ViewRegister(ID);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("UpdateRegister")]
        public IActionResult UpdateRegister(RegisterModel reg)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.UpdateRegister(reg);
                return Ok(res);
            }
            catch(Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("DeleteRegister")]
        public IActionResult DeleteRegister(int ID)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.DeleteRegister(ID);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
