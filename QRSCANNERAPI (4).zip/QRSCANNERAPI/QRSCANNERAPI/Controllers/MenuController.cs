﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MODEL;
using REPOSITORY;

namespace QRSCANNERAPI.Controllers
{
    [Route("api/controller/Menu")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly MenuRepository _service;
        public MenuController(MenuRepository service)
        {
            _service = service;
        }

        [HttpGet]
        [Route("GetAllMenu")]
        public IActionResult GetAllMenu()
        {
            try
            {
                List<MenuModel> menu = _service.MenuAll();
                return Ok(menu);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("AddMenu")]
        public IActionResult AddMenu(MenuModel MM)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.AddMenu(MM);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("ViewMenu")]
        public IActionResult ViewMenu(int MenuId)
        {
            MenuModel MM = new MenuModel();
            try
            {
                MM = _service.ViewMenu(MenuId);
                return Ok(MM);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("UpdateMenu")]
        public IActionResult UpdateMenu(MenuModel MM)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.UpdateMenu(MM);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
       

        [HttpGet]
        [Route("DeleteMenu")]
        public IActionResult DeleteMenu(int MenuId)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.DeleteMenu(MenuId);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
