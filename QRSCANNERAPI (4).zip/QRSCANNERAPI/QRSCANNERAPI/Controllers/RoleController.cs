﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MODEL;
using REPOSITORY;

namespace QRSCANNERAPI.Controllers
{
    [Route("api/controller/Role")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly RoleRepository _service;

        public RoleController(RoleRepository service) 
        {
            _service = service;
        }

        [HttpGet]
        [Route("GetAllRole")]
        public IActionResult GetAllRoles()
        {
            try
            {
                List<RoleModel> roles = _service.GetAllRoles();
                return Ok(roles);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("AddRole")]
        public IActionResult AddRole(RoleModel role)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.AddRole(role);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("ViewRole")]
        public IActionResult ViewRole(int RoleId)
        {
            RoleModel Role = new RoleModel();
            try
            {
                Role = _service.ViewRole(RoleId);
                return Ok(Role);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpPost]
        [Route("UpdateRole")]
        public IActionResult UpdateRole(RoleModel Role)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.UpdateRole(Role);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("DeleteRole")]
        public IActionResult DeleteRole(int RoleId)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                res = _service.DeleteRole(RoleId);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
