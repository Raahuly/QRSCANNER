﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MODEL;
using REPOSITORY;
using System.Security.Cryptography;

namespace QRSCANNERAPI.Controllers
{
    [Route("api/controller/QRSCAN")]
    [ApiController]
    public class QRScannerController : ControllerBase
    {
        private readonly QRScannerRepository _service;
        private string _FolderNameImagePath;

        private readonly IConfiguration _configuration;
        private readonly string[] _validExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".jfif", ".bmp", ".tiff", ".webp", ".ico" };

        public QRScannerController(QRScannerRepository service, IConfiguration configuration)
        {
            _service = service;
            _configuration = configuration;
            _FolderNameImagePath = configuration["Jwt:FolderNameImagePath"];
        }

        [HttpGet]
        [Route("AllQRSCAN")]
        public IActionResult AllQRSCAN()
        {
            try
            {
                List<QRScannerModel> QRSCAN = _service.QRScanAll();
                return Ok(QRSCAN);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpPost]
        [Route("AddQRSCAN")]
        public IActionResult AddQRSCAN([FromForm] QRScannerModel QM)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            try
            {
                Console.WriteLine($"Name: {QM.NAME}, Number: {QM.NUMBER}, File: {QM.File?.FileName}");

                if (QM.File != null)
                {

                    var extension = Path.GetExtension(QM.File.FileName).ToLowerInvariant();
                    if (!Array.Exists(_validExtensions, ext => ext == extension))
                    {
                        return BadRequest(new
                        {
                            statusCode = StatusCodes.Status400BadRequest,
                            statusMsg = "Invalid file type."
                        });
                    }


                    var uploadsFolder = Path.Combine(_FolderNameImagePath);
                    var filePath = Path.Combine(uploadsFolder, QM.File.FileName);
                    QM.IMAGEPATH = "http://localhost:5173/public/" + QM.File.FileName;
                    Directory.CreateDirectory(uploadsFolder);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        QM.File.CopyTo(stream);
                    }
                }

                res = _service.AddQRScanner(QM);
                if(res.MSG == "SUCCESSFULLY")
                {
                    string ID;
                    ID = _service.GetIdForQrCode(QM.NUMBER);
                    return Ok(ID);
                }
                return Ok(res);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
