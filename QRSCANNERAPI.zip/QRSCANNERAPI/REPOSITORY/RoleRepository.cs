﻿using Dapper;
using MODEL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REPOSITORY
{
    public class RoleRepository
    {
        private readonly Connection _connection;

        public RoleRepository(Connection connection)
        {
            _connection = connection;
        }

        public List<RoleModel> GetAllRoles()
        {
            List<RoleModel> roles = new List<RoleModel>();
            string sql = "[dbo].[AllROLES]";

            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, commandType: CommandType.StoredProcedure);
                roles = multi.Read<RoleModel>().ToList();
            }

            return roles;
        }

        public ResponseStatusModel AddRole(RoleModel role)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].AddRole";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    role.RoleName
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

        public RoleModel ViewRole(int RoleId)
        {
            RoleModel role = new RoleModel();
            string sql = "[dbo].[GetByRoleId]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    RoleId = RoleId
                }, commandType: CommandType.StoredProcedure);
                role = multi.Read<RoleModel>().SingleOrDefault();
            }
            return role;
        }

        public ResponseStatusModel UpdateRole(RoleModel Role)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[UpdateRole]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    Role.RoleId,
                    Role.RoleName
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

        public ResponseStatusModel DeleteRole(int RoleId)
        {
            ResponseStatusModel res = new ResponseStatusModel();
            string sql = "[dbo].[RemoveRole]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    RoleId
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<ResponseStatusModel>().SingleOrDefault();
            }
            return res;
        }

    }
}

